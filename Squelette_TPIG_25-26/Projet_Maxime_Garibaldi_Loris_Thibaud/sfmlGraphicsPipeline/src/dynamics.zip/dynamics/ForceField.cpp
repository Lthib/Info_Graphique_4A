#include "../../include/dynamics/ForceField.hpp"

ForceField::ForceField(){}

ForceField::~ForceField(){}

void ForceField::addForce()
{
  do_addForce();
}
